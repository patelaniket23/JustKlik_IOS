//
//  Constants.swift
//  Aniket_Patel_Final_Project
//
//  Created by Aniket Patel on 2021-04-14.
//

import Foundation

struct Constants {
    
    struct Storyboard {
        
        // static is used to access the instances 
       static let IMPViewController = "MainVC"
    }
}

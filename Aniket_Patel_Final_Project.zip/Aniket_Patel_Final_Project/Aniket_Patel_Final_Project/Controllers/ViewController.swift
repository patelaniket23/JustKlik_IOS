//
//  ViewController.swift
//  Aniket_Patel_Final_Project
//
//  Created by Aniket Patel on 2021-04-13.
//

import UIKit

class ViewController: UIViewController {
    
    //  Reference : https://www.youtube.com/watch?v=1HN7usMROt8
    
    @IBOutlet weak var signUpButton: UIButton!
    
    @IBOutlet weak var loginButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

